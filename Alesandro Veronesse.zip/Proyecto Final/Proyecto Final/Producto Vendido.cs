﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Producto_Vendido
    {
        public int Id;
        public int IdProducto;
        public int Stock;
        public int IdVenta;

        public Producto_Vendido()
        {
        }

    }
}
