﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Producto
    {
        public int Id;
        public string Descripcion;
        public string Costo;
        public double PrecioVenta;
        public int Stock;
        public string IdUsuario;
        public Producto()
        {
            
        }
    }
}
