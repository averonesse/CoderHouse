﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Usuario
    {
        public int Id;
        public string Nombre;
        public string Apellido;
        public string NombreUsuario;
        public string Contrasenia;
        public string Mail;

        public Usuario()
        {

        }
    }
}
